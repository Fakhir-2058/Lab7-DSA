#include "Node.h"

class LL
{
protected:
	Node* head;
public:
	LL();
	virtual void CreateNode(int) = 0;
	virtual void display() = 0;
	virtual bool isEmpty() = 0;
};

LL::LL()
{
	head = nullptr;
}