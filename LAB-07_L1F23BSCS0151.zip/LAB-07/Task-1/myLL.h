#include "LL.h"

class myLL :public LL
{

public:
	myLL();
	void CreateNode(int);
	void display();
	bool isEmpty();
};

myLL::myLL() :LL()
{

}

bool myLL::isEmpty()
{
	return head == nullptr;
}


void myLL::CreateNode(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr) 
	{
		head = nn;
	}

	else 
	{
		Node* temp = head;

		while (1)
		{
			if (temp->next == nullptr)
				break;

			temp = temp->next;
		}

		temp->next = nn;


	}
}

void myLL::display()
{
	cout << "Displaying LL" << endl;
	if (head == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* temp = head;

		while (temp != nullptr)
		{
			cout << temp->data << endl;
			temp = temp->next;
		}
	}
}


