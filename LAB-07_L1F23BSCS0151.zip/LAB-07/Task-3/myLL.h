#include "LinkedList.h"

class myLL :public LinkedList
{
private:
	int countNodes = 0;
public:
	void display();
	bool isEmpty();
	void insertAtTail(int);
	void insertAtHead(int);
	int deleteFromTail();
	int deleteFromHead();
	bool search(int);
	bool deleteValue(int);
	int nodesCount();
	void insertAtPosition(int value, int position);
};

void  myLL::insertAtPosition(int value, int position) {

	if (position == 0) {
		insertAtHead(value);
	}
	else {
		Node* newNode = new Node;
		newNode->data = value;
		countNodes++;

		Node* temp = head;
		int currentPos = 0;

		while (temp != nullptr && currentPos < position - 1) {
			temp = temp->next;
			currentPos++;
		}

		if (temp == nullptr) {
			cout << "Position out of bounds." << endl;
			delete newNode;
			return;
		}

		newNode->next = temp->next;
		temp->next = newNode;
	}
}

bool myLL::deleteValue(int value)
{
	if (isEmpty())
		return false;

	else if (head == tail)
	{
		if (head->data == value)
		{
			delete head;
			head = nullptr;
			tail = nullptr;
			return true;
		}

		else
			return false;
	}

	else if (head->data == value)
	{
		deleteFromHead();
		return true;
	}

	else if (tail->data == value)
	{
		deleteFromTail();
		return true;
	}

	else
	{
		Node* temp = head;

		while (1)
		{
			if (temp->next->data == value)
				break;

			else
				temp = temp->next;

			if (temp == tail)
				return false;
		}

		Node* t2 = temp->next;
		temp->next = temp->next->next;
		delete t2;
		t2 = nullptr;

		return true;
	}

}

bool myLL::search(int value)
{
	if (isEmpty())
		return false;

	else
	{
		Node* temp = head;

		while (1)
		{
			if (temp->data == value)
				return true;

			temp = temp->next;

			if (temp == nullptr)
				return false;
		}
	}
}

int myLL::deleteFromHead()
{
	if (isEmpty())
		return NULL;

	if (head == tail)
	{
		int returningValue = head->data;
		delete tail;
		head = nullptr;
		tail = nullptr;
		return returningValue;
	}

	else
	{
		Node* temp = head;
		int returningValue = head->data;

		head = head->next;
		delete temp;
		temp = nullptr;

		return returningValue;

	}
}


int myLL::deleteFromTail()
{
	if (isEmpty())
		return NULL;

	if (head == tail)
	{
		int returningValue = head->data;
		delete tail;
		head = nullptr;
		tail = nullptr;
		return returningValue;
	}

	else
	{
		Node* temp = head;

		while (1)
		{
			if (temp->next == tail)
				break;

			else
				temp = temp->next;

		}
		int returningValue = tail->data;
		delete tail;
		tail = temp;
		temp->next = nullptr;
		return returningValue;

	}
}

bool myLL::isEmpty()
{
	return head == nullptr && tail == nullptr;
}

void myLL::display()
{
	if (head == nullptr && tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}
}

void myLL::insertAtTail(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	countNodes++;

	if (head == nullptr && tail == nullptr)
	{
		head = nn;
		tail = nn;
	}

	else
	{
		tail->next = nn;
		tail = nn;
	}
}

void myLL::insertAtHead(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	countNodes++;
	if (head == nullptr && tail == nullptr)
	{
		head = nn;
		tail = nn;
	}

	else
	{
		nn->next = head;
		head = nn;

	}
}
int myLL::nodesCount() {
	return countNodes;
}