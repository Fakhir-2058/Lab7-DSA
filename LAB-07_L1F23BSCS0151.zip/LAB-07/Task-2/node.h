struct node
{
	int data;
	node* next;
};