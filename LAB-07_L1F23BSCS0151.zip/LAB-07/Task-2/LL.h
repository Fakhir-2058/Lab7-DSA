#include "node.h"
#include<iostream>
using namespace std;

class linkedlist
{
protected:
	node* head;
	linkedlist();
	virtual void insertvalueatend(int) = 0;
	virtual void insertvalueatstart(int) = 0;
	virtual bool deletvalue(int) = 0;
};

linkedlist::linkedlist()
{
	head = nullptr;
}



