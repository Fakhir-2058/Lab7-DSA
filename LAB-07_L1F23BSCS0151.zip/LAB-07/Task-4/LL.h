#include "Node.h"
#include<iostream>
using namespace std;

class linkedlist
{
protected:
	node* head;
	int count;
public:
	linkedlist();
	virtual bool isempty() = 0;
	virtual void Add_new_patient(string) = 0;
	virtual string Remove_patient() = 0;
};

linkedlist::linkedlist()
{
	head = nullptr;
	count = 0;
}



