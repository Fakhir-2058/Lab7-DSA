#include"LL.h"

class myLL : public linkedlist
{
public:
	myLL();
	void Add_new_patient(string);
	bool isempty();
	string Remove_patient();
	void display();
};
myLL::myLL() :linkedlist()
{

}
void myLL::Add_new_patient(string value)
{
	node* nn = new node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
		count++;
	}
	else
	{
		node* temp = head;
		while (1)
		{
			if (temp->next == nullptr)
				break;

			temp = temp->next;

		}
		temp->next = nn;
		count++;
	}
}
bool myLL::isempty()
{
	return head == nullptr;
}

string myLL::Remove_patient()
{
	if (isempty())
		return "NULL";

	if (head->next == nullptr)
	{
		string returningValue = head->data;
		delete head;
		head = nullptr;
		count--;
		return returningValue;
	}

	else
	{
		node* temp = head;
		string returningValue = head->data;

		head = head->next;
		delete temp;
		temp = nullptr;
		count--;
		return returningValue;

	}
}






void myLL::display()
{
	cout << "Total Patients: " << count << endl;
	if (head == nullptr)
	{
		cout << " No Record Found " << endl;
	}
	else
	{
		node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}

}