#include"LL.h"

class myLL : public linkedlist
{
public:
	myLL();
	void insertvalueatend(string);
	void insertvalueatstart(string);
	bool isempty();
	string deletefromhead();
	void display();

};
myLL::myLL() :linkedlist()
{

}
void myLL::insertvalueatend(string value)
{
	node* nn = new node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}
	else
	{
		node* temp = head;
		while (1)
		{
			if (temp->next == nullptr)
				break;

			temp = temp->next;

		}
		temp->next = nn;
	}
}
void myLL::insertvalueatstart(string value)
{
	node* nn = new node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}

	else
	{
		nn->next = head;
		head = nn;

	}
}
bool myLL::isempty()
{
	return head == nullptr;
}
string myLL::deletefromhead()
{
	if (isempty())
		return "NULL";

	if (head->next == nullptr)
	{
		string returningValue = head->data;
		delete head;
		head = nullptr;
		return returningValue;
	}

	else
	{
		node* temp = head;
		string returningValue = head->data;

		head = head->next;
		delete temp;
		temp = nullptr;

		return returningValue;

	}
}








void myLL::display()
{
	if (head == nullptr)
	{
		cout << " The linkedlist is empty " << endl;
	}
	else
	{
		node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}

}